
function GetAllByType(){
	console.log("---已进入js方法");
	var type_id=document.getElementById("type_id").innerHTML;
	//url="http://localhost:8080/wxsc/GetType?type_id="+type_id;
	url="http://localhost:8080/wxsc/Types/"+type_id;

	console.log("type_id="+type_id);
	 $.ajax({
		 url :url,
		 type:"get",
		 dataType:"json",
		 success:function(data){
			 console.log("data已获取");
			 console.log(data);		
			 var result=eval(data);
			 $.each(result, function (index, item) {  
	             //循环获取数据    
	             var name = result[index].goodsname;  
	             var goods_price = result[index].goodsprice;  
	             var goods_class = result[index].goodsclass;  
	             $("#myresult").html($("#myresult").html() + "<br>" + name + " - " + goods_price + " - " + goods_class + "<br/>");  
	         }); 
			 
		 },
	 error:function(data){ console.log("data获取失败");}
	 });		
	}


function description(){
	console.log("js方法进入成功");
	var goodsid=document.getElementById("goodsid2").innerHTML;
	// url="./getDescription?goodsid="+goodsid;
	 url="http://localhost:8080/wxsc/getDescription?goodsid="+goodsid;
	console.log("url="+url);
	 $.ajax({
		 url :url,
		 type:"get",
		 dataType:"json",
		 success:function(data){
			 console.log("后台返回的data已获取");
			 console.log(data);		
			 var result=eval(data);
			 $.each(result, function (index, item) {  
	             //循环获取数据    
	             var name = result[index].goodsname;  
	             var goods_price = result[index].goodsprice;  
	             var goods_class = result[index].goodsclass;  
	             $("#myresult").html($("#myresult").html() + "<br>" + name + " - " + goods_price + " - " + goods_class + "<br/>");  
	         }); 
			 
		 },
	 error:function(data){ console.log("data获取失败");}
	 });
		
		
		
	}

