package com.wxsc.bean;
/**
 * 
 * ���﹦��bean
 *
 */
public class SHOP_GOODS {
	private String goodsid;
	private String custid;
	private String num;
	private String total;
	
	public String getGoodsid() {
		return goodsid;
	}
	
	public void setGoodsid(String goodsid) {
		this.goodsid = goodsid == null ? null : custid.trim();
	}
	
	public String getCustid() {
		return custid;
	}
	
	public void setCustid(String custid) {
		this.custid = custid == null ? null : custid.trim();
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num == null ? null : num.trim();
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total == null ? null : total.trim();
	}
	
	
	
}
