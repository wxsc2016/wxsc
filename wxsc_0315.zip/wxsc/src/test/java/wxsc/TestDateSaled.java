package wxsc;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.wxsc.service.ShowGoodsServiceI;


@ContextConfiguration(locations = {"classpath:spring.xml", "classpath:spring-mybatis.xml" })
public class TestDateSaled {
	@Autowired
	private ShowGoodsServiceI ssi;
@Test
public void testSaled(){
	
	/*private DATE_SALEDMapper dsmapper;
	dsmapper.selectByPrimaryKey("12");
	*/

	ssi.showAll("vegetable");
	
}
}
