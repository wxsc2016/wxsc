package com.wxsc.service;

import java.util.List;

import com.wxsc.bean.SHOP_GOODS;
/**
 * 
 * ���﹦�ܽӿ�
 *
 */
public interface ShopGoodsServiceI {
	public List<SHOP_GOODS> showAll(String goodsClass);
}
